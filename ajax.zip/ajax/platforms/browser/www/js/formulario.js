 function SubForm (){
    $.ajax({
        url:'https://uniapp1.000webhostapp.com/teste.php',
        type:'post',
        data:$('#myForm').serialize(),
        success:function(){
            alert("worked");
        }
    });
}